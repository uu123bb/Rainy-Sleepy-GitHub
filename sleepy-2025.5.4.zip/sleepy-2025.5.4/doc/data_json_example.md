# `data.json` example

```jsonc
// example
{
    "status": 0, // 当前状态 (setting/status_list.json 索引)
    "device_status": {}, // 设备状态列表
    "private_mode": false, // 隐私模式 (不返回上面这个)
    "last_updated": "1970-01-01 08:00:01" // 最后更新
}
```